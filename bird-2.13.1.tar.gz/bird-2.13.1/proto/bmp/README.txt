ABOUT
This package |proto/bmp/*| provide implementation of BGP Monitoring Protocol (BMP).
It has been started by Akamai Technologies, Inc. as a pilot program for support BMP in BIRD.
It provides only basic features of BMP specification which are needed by Akamai evaluation of 
feasible BMP protocol.
Content of this package has been provided as a patch for BIRD release v2.0.7.